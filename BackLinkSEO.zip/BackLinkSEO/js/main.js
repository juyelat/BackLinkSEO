$('.header-menu ul li a').on('click',function(){
    $('.header-menu ul li a').removeClass('active1')
    $(this).addClass('active1')
})
$('.main-menu ul li a').on('click',function(){
    $('.main-menu ul li a').removeClass('active')
    $(this).addClass('active')
})

const mydark=document.getElementById('dark-check')
mydark.onclick=function(){
    document.body.classList.toggle('campain-dark')
}

$('.campain-box-top svg').click(function(){
    let data=$(this).attr('data-val')
    console.log(data)
    if(data=='1'){
        $('.box-text1').slideToggle()
    }
    if(data=='2'){
        $('.box-text2').slideToggle()
    }
    if(data=='3'){
        $('.box-text3').slideToggle()
    }
    if(data=='4'){
        $('.box-text4').slideToggle()
    }
    if(data=='5'){
        $('.box-text5').slideToggle()
    }
    if(data=='6'){
        $('.box-text6').slideToggle()
    }
    if(data=='7'){
        $('.box-text7').slideToggle()
    }
    if(data=='8'){
        $('.box-text8').slideToggle()
    }
    if(data=='9'){
        $('.box-text9').slideToggle()
    }
    if(data=='10'){
        $('.box-text10').slideToggle()
    }
    if(data=='11'){
        $('.box-text11').slideToggle()
    }
})


$('#bar-icon').click(function(){
    $('#campain_menu').toggle()
})

